//
//  PostNewLogin.swift
//  Hey_Groot
//
//  Created by 황수비 on 2023/08/20.
//

import Foundation

struct PostLogin: Decodable {
    var refresh_token: String
    var access_token: String
    var user: User
}

struct User: Decodable {
    var pk: Int
    var email: String
    var nickName: String?
    var last_login: String
}
