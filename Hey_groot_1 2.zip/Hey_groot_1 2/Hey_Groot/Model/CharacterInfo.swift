//
//  CharacterInfo.swift
//  Hey_Groot
//
//  Created by 서명주 on 11/16/23.
//

class CharacterInfo:Codable{
    var id:Int?
    var name:String?
    var basic_emo:String?
    var sad_emo:String?
    var happy_emo:String?
}


