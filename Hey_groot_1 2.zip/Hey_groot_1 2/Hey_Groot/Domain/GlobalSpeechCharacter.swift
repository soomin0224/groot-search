//
//  GlobalSpeechCharacter.swift
//  Hey_Groot
//
//  Created by 황수비 on 2023/09/10.
//

import UIKit

class GlobalSpeechCharacter {
    static let shared = GlobalSpeechCharacter()
    
    var systemSpeechCharacterImageName: String = "Character1"
    

}
