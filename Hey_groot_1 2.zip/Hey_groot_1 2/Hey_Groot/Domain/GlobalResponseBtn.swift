//
//  GlobalResponseBtn.swift
//  Hey_Groot
//
//  Created by 황수비 on 2023/09/09.
//

import Foundation
import UIKit

class GlobalResponseBtn {
    static let shared = GlobalResponseBtn()
    
    var systemResponseBtnImageName: String = "Character"
}
